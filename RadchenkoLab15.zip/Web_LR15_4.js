/* 
Завдання 4:

В змінній month лежить якесь число з діапазону від 1 до 12. Визначте в яку пору року потрапляє цей місяць
(зима, літо, весна, осінь) і яку цей місяць має назву. Число з діапазону отримувати з допомогою модального вікна prompt,
результат роботи виводити в модальному вікні alert. */

let vvodmonth = prompt("Будь ласка, введіть число від 1 до 12: ");

let month = parseInt(vvodmonth);
var season = "";
var monthname = "";

if (month !== null)
{
    if (!isNaN(month)) {
        if (month >=1 && month <= 12)
        {
            if (month == 12 || month == 1 || month == 2) {
                season = "Зима";
				document.body.style.backgroundImage = "url(https://s1.picswalls.com/wallpapers/2014/02/08/beautiful-winter-wallpaper_03382016_27.jpg)";
                if (month == 12) {
                    monthname = "Грудень";
                }
                if (month == 1) {
                    monthname = "Січень";
                }
                if (month == 2) {
                    monthname = "Лютий";
                }
            }
            if (month == 3 || month == 4 || month == 5) {
                season = "Весна";
				document.body.style.backgroundImage = "url(https://i.pinimg.com/originals/a2/7c/a5/a27ca5344f0e5a3f9be1882b772a89cf.jpg)";
                if (month == 3) {
                    monthname = "Березень";
                }
                if (month == 4) {
                    monthname = "Квітень";
                }
                if (month == 5) {
                    monthname = "Травень";
                }
            }
            if (month == 6 || month == 7 || month == 8) {
                season ="Літо";
				document.body.style.backgroundImage = "url(https://i.pinimg.com/originals/7c/72/4a/7c724ae8790a81e44c3068ab43c63aba.jpg)";
                if (month == 6) {
                    monthname = "Червень";
                }
                if (month == 7) {
                    monthname = "Липень";
                }
                if (month == 8) {
                    monthname = "Серпень";
                }
            }
            if (month == 9 || month == 10 || month == 11) {
                season = "Осінь";
				document.body.style.backgroundImage = "url(https://i.pinimg.com/originals/df/1d/b9/df1db996e51c28f9be0afd94da129442.jpg)";
                if (month == 9) {
                    monthname = "Вересень";
                }
                if (month == 10) {
                    monthname = "Жовтень";
                }
                if (month == 11) {
                    monthname = "Листопад";
                }
            }
            alert("Ви ввели число " + month + ".\n" + "Дане число відповідає місяцю " + monthname + ".\n" + "Пора року: " + season + ".");
        }
        else
        {
            console.log("Треба ввести число в діапазоні від 1 до 12.");
        }
    }
    else
    {
        console.log("Ви ввели не число.");
    }
}
else
{
    console.log("Ви нічого не ввели! (ERROR: Month = null).");
}