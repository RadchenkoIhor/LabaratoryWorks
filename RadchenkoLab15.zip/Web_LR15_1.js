let n = 0;

while ( n <= 100 ) {
    console.log(n);
    n++;
}